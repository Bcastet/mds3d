J'ai fait toutes les questions abordées dans le sujet.
Actuellement, mon programme affiche le système solaire avec les réflexions 
de Blinn-Phong, ainsi que le calcul des normales.

Difficultés rencontrées:
Comprendre comment manipuler un objet correctement (translations, rotations...)
a été assez long, et j'ai beaucoup tattoné pour arriver au résultat attendu.
